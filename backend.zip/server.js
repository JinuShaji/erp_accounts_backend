require('dotenv').config();
const express = require('express');
const cors = require('cors');
const db = require('./config/db');
const customerRoutes = require('./routes/customers');
const invoiceRoutes = require('./routes/invoice');
const paymentRoutes = require('./routes/payments');
const accountingRoutes = require('./routes/accounting');
const ensureAccountingSchema = require('./config/ensureAccountingSchema');

const app = express();
app.use(cors());
app.use(express.json());
app.use('/api/customers', customerRoutes);
app.use('/api/invoices', invoiceRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api', accountingRoutes);

app.get('/', (req, res) => res.json({ message: 'ERP Customer API is running' }));

const PORT = process.env.PORT || 5000;
(async () => {
  try {
    await db.query('SELECT 1');
    await ensureAccountingSchema();
    console.log('Accounting tables are ready');
    console.log('MySQL connected successfully');
    app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
  } catch (error) {
    console.error('Database connection failed:', error.message);
    process.exit(1);
  }
})();
