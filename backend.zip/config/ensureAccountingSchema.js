const db = require('./db');
const { createPostedJournal } = require('../utils/journals');

async function postLegacyInvoices() {
  const [invoices] = await db.execute(`
    SELECT id, unique_invoice_no, invoice_date, subtotal, tax_amount, total
    FROM invoice
    WHERE status IN ('issued', 'partial', 'paid')
    ORDER BY id
  `);

  for (const invoice of invoices) {
    if (Number(invoice.total) <= 0) {
      console.warn(`Skipping zero-total legacy invoice ${invoice.id}; no balanced journal can be posted`);
      continue;
    }

    const connection = await db.getConnection();
    try {
      await connection.beginTransaction();
      const [existing] = await connection.execute(
        'SELECT id FROM journal_entries WHERE reference_type = ? AND reference_id = ?',
        ['invoice', invoice.id]
      );
      if (!existing.length) {
        const lines = [
          {
            accountCode: '1100',
            description: `Accounts receivable for ${invoice.unique_invoice_no}`,
            debit: invoice.total,
            credit: 0
          },
          {
            accountCode: '4000',
            description: `Sales revenue for ${invoice.unique_invoice_no}`,
            debit: 0,
            credit: invoice.subtotal
          }
        ];
        if (Number(invoice.tax_amount) > 0) {
          lines.push({
            accountCode: '2100',
            description: `Tax payable for ${invoice.unique_invoice_no}`,
            debit: 0,
            credit: invoice.tax_amount
          });
        }
        await createPostedJournal(connection, {
          entryDate: invoice.invoice_date,
          referenceType: 'invoice',
          referenceId: invoice.id,
          description: `Invoice issued: ${invoice.unique_invoice_no}`,
          lines
        });
      }
      await connection.commit();
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  }
}

async function postLegacyPayments() {
  const [payments] = await db.execute(`
    SELECT id, invoice_id, date, amount, payment_method
    FROM payments
    ORDER BY id
  `);

  for (const payment of payments) {
    const connection = await db.getConnection();
    try {
      await connection.beginTransaction();
      const [existing] = await connection.execute(
        'SELECT id FROM journal_entries WHERE reference_type = ? AND reference_id = ?',
        ['payment', payment.id]
      );
      if (!existing.length) {
        const cashAccount = String(payment.payment_method).trim().toLowerCase() === 'cash' ? '1000' : '1010';
        await createPostedJournal(connection, {
          entryDate: payment.date,
          referenceType: 'payment',
          referenceId: payment.id,
          description: `Payment received for invoice ${payment.invoice_id}`,
          lines: [
            {
              accountCode: cashAccount,
              description: `Funds received by ${payment.payment_method}`,
              debit: payment.amount,
              credit: 0
            },
            {
              accountCode: '1100',
              description: `Accounts receivable settled for invoice ${payment.invoice_id}`,
              debit: 0,
              credit: payment.amount
            }
          ]
        });
      }
      await connection.commit();
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  }
}

async function ensureAccountingSchema() {
  const [invoiceNumberColumns] = await db.execute(`
    SELECT COLUMN_TYPE
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'invoice'
      AND COLUMN_NAME = 'unique_invoice_no'
  `);
  if (!invoiceNumberColumns.length) {
    throw new Error('Invoice number column is missing');
  }
  if (/^int/i.test(invoiceNumberColumns[0].COLUMN_TYPE)) {
    await db.query('ALTER TABLE invoice MODIFY unique_invoice_no VARCHAR(50) NOT NULL');
    await db.query("UPDATE invoice SET unique_invoice_no = CONCAT('INV-', LPAD(id, 8, '0'))");
  } else {
    await db.query(`
      UPDATE invoice
      SET unique_invoice_no = CONCAT('INV-', LPAD(id, 8, '0'))
      WHERE unique_invoice_no = '0' OR unique_invoice_no = ''
    `);
  }
  const [invoiceNumberIndexes] = await db.execute(`
    SELECT INDEX_NAME
    FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'invoice'
      AND COLUMN_NAME = 'unique_invoice_no'
      AND NON_UNIQUE = 0
  `);
  if (!invoiceNumberIndexes.length) {
    await db.query('ALTER TABLE invoice ADD UNIQUE KEY uq_invoice_unique_no (unique_invoice_no)');
  }

  await db.query(`
    ALTER TABLE invoice
      MODIFY subtotal DECIMAL(15, 2),
      MODIFY tax_amount DECIMAL(15, 2),
      MODIFY total DECIMAL(15, 2)
  `);
  await db.query(`
    ALTER TABLE invoice_line_items
      MODIFY quantity DECIMAL(15, 3),
      MODIFY unit_price DECIMAL(15, 2),
      MODIFY tax_rate DECIMAL(5, 2),
      MODIFY line_total DECIMAL(15, 2)
  `);
  await db.query('ALTER TABLE payments MODIFY amount DECIMAL(15, 2)');
  await db.query(`
    ALTER TABLE payments
      MODIFY payment_method VARCHAR(30) NOT NULL,
      MODIFY reference_no VARCHAR(100) NULL
  `);
  await db.query(`
    UPDATE payments
    SET payment_method = 'Bank transfer'
    WHERE payment_method = '0' OR payment_method = ''
  `);
  await db.query("UPDATE payments SET reference_no = NULL WHERE reference_no = '0'");

  await db.query(`
    CREATE TABLE IF NOT EXISTS accounts (
      id INT AUTO_INCREMENT PRIMARY KEY,
      account_code VARCHAR(20) NOT NULL UNIQUE,
      name VARCHAR(120) NOT NULL,
      type VARCHAR(20) NOT NULL,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB
  `);
  await db.query(`
    CREATE TABLE IF NOT EXISTS journal_entries (
      id BIGINT AUTO_INCREMENT PRIMARY KEY,
      entry_date DATE NOT NULL,
      reference_type VARCHAR(20) NOT NULL,
      reference_id BIGINT NULL,
      description VARCHAR(255) NOT NULL,
      status VARCHAR(10) NOT NULL DEFAULT 'posted',
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY uq_journal_source (reference_type, reference_id),
      CONSTRAINT chk_journal_status CHECK (status = 'posted')
    ) ENGINE=InnoDB
  `);
  await db.query(`
    CREATE TABLE IF NOT EXISTS journal_entry_lines (
      id BIGINT AUTO_INCREMENT PRIMARY KEY,
      journal_entry_id BIGINT NOT NULL,
      account_id INT NOT NULL,
      description VARCHAR(255) NULL,
      debit DECIMAL(15, 2) NOT NULL DEFAULT 0,
      credit DECIMAL(15, 2) NOT NULL DEFAULT 0,
      CONSTRAINT fk_journal_lines_entry
        FOREIGN KEY (journal_entry_id) REFERENCES journal_entries(id)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
      CONSTRAINT fk_journal_lines_account
        FOREIGN KEY (account_id) REFERENCES accounts(id)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
      CONSTRAINT chk_journal_line_amounts CHECK (
        (debit > 0 AND credit = 0) OR (credit > 0 AND debit = 0)
      )
    ) ENGINE=InnoDB
  `);

  await db.query(`
    INSERT IGNORE INTO accounts (account_code, name, type) VALUES
      ('1000', 'Cash on Hand', 'asset'),
      ('1010', 'Bank', 'asset'),
      ('1100', 'Accounts Receivable', 'asset'),
      ('2100', 'Tax Payable', 'liability'),
      ('3000', 'Owner Equity', 'equity'),
      ('4000', 'Sales Income', 'income'),
      ('5000', 'Operating Expense', 'expense')
  `);

  const [accountTypeChecks] = await db.execute(`
    SELECT CONSTRAINT_NAME
    FROM information_schema.CHECK_CONSTRAINTS
    WHERE CONSTRAINT_SCHEMA = DATABASE()
      AND CONSTRAINT_NAME = 'chk_accounts_type'
  `);
  if (accountTypeChecks.length) {
    await db.query('ALTER TABLE accounts DROP CONSTRAINT chk_accounts_type');
  }
  await db.query("UPDATE accounts SET name = 'Cash', type = 'asset' WHERE account_code = '1000'");
  await db.query("UPDATE accounts SET name = 'Bank', type = 'asset' WHERE account_code = '1010'");
  await db.query("UPDATE accounts SET name = 'Accounts Receivable', type = 'asset' WHERE account_code = '1100'");
  await db.query("UPDATE accounts SET name = 'GST Payable', type = 'liability' WHERE account_code = '2100'");
  await db.query("UPDATE accounts SET name = 'Owner''s Capital', type = 'equity' WHERE account_code = '3000'");
  await db.query("UPDATE accounts SET name = 'Sales Income', type = 'income' WHERE account_code = '4000'");
  await db.query("UPDATE accounts SET name = 'General Expense', type = 'expense' WHERE account_code = '5000'");
  await db.query(`
    ALTER TABLE accounts
    ADD CONSTRAINT chk_accounts_type
    CHECK (type IN ('asset', 'liability', 'equity', 'income', 'expense'))
  `);

  await postLegacyInvoices();
  await postLegacyPayments();
}

module.exports = ensureAccountingSchema;
