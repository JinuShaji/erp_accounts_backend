
const express = require('express');
const crypto = require('crypto');
const db = require('../config/db');
const { createPostedJournal } = require('../utils/journals');

const router = express.Router();

const validDate = (date) =>
  typeof date === 'string' &&
  /^\d{4}-\d{2}-\d{2}$/.test(date) &&
  !Number.isNaN(Date.parse(date)) &&
  new Date(date).toISOString().slice(0, 10) === date;

function calculateInvoiceItems(items) {
  if (!Array.isArray(items) || items.length === 0) {
    return { error: 'At least one invoice item is required' };
  }
  if (items.length > 500) {
    return { error: 'Maximum 500 line items allowed' };
  }

  let subtotal = 0;
  let taxAmount = 0;
  const cleanItems = [];

  for (const item of items) {
    if (
      !item ||
      item.quantity === undefined ||
      item.quantity === null ||
      item.quantity === '' ||
      item.unit_price === undefined ||
      item.unit_price === null ||
      item.unit_price === ''
    ) {
      return { error: 'Invalid invoice item' };
    }

    const quantity = Number(item?.quantity);
    const unitPrice = Number(item?.unit_price);
    const taxRate = Number(item?.tax_rate ?? 0);
    const description = typeof item?.description === 'string' ? item.description.trim() : '';

    if (
      !description ||
      description.length > 255 ||
      !Number.isFinite(quantity) ||
      !Number.isFinite(unitPrice) ||
      !Number.isFinite(taxRate) ||
      quantity <= 0 ||
      unitPrice < 0 ||
      taxRate < 0 ||
      taxRate > 100 ||
      quantity > 1000000 ||
      unitPrice > 100000000
    ) {
      return { error: 'Invalid invoice item' };
    }

    const lineSubtotal = Number((quantity * unitPrice).toFixed(2));
    const lineTax = Number((lineSubtotal * taxRate / 100).toFixed(2));
    const lineTotal = Number((lineSubtotal + lineTax).toFixed(2));

    subtotal = Number((subtotal + lineSubtotal).toFixed(2));
    taxAmount = Number((taxAmount + lineTax).toFixed(2));
    cleanItems.push({ description, quantity, unitPrice, taxRate, lineTotal });
  }

  return {
    cleanItems,
    subtotal,
    taxAmount,
    total: Number((subtotal + taxAmount).toFixed(2))
  };
}

function validInvoiceDates(invoiceDate, dueDate) {
  if (!validDate(invoiceDate) || !validDate(dueDate)) {
    return 'Invalid invoice or due date';
  }
  if (dueDate < invoiceDate) {
    return 'Due date cannot be before invoice date';
  }
  return null;
}

// API 1: Create Draft Invoice with Line Items
// POST /api/invoices
router.post('/', async (req, res) => {
  const connection = await db.getConnection();

  try {
    const {
      cusomer_id,
      invoice_date,
      due_date,
      items
    } = req.body;

    if (
      !Number.isInteger(Number(cusomer_id)) ||
      Number(cusomer_id) <= 0 ||
      !invoice_date ||
      !due_date ||
      !Array.isArray(items) ||
      items.length === 0
    ) {
      return res.status(400).json({
        message: 'Customer, dates and invoice items are required'
      });
    }

    const dateError = validInvoiceDates(invoice_date, due_date);
    if (dateError) {
      return res.status(400).json({
        message: dateError
      });
    }

    const calculated = calculateInvoiceItems(items);
    if (calculated.error) {
      return res.status(400).json({ message: calculated.error });
    }
    const { cleanItems, subtotal, taxAmount, total } = calculated;

    // Unique invoice number
    const invoiceNo =
      'INV-' + crypto.randomUUID();

    await connection.beginTransaction();

    // Validate customer
    const [customers] = await connection.execute(
      'SELECT id FROM customer WHERE id = ?',
      [Number(cusomer_id)]
    );

    if (customers.length === 0) {
      await connection.rollback();
      return res.status(404).json({
        message: 'Customer not found'
      });
    }

    const [result] = await connection.execute(
      `INSERT INTO invoice
       (unique_invoice_no, cusomer_id, invoice_date,
        due_date, status, subtotal, tax_amount, total)
       VALUES (?, ?, ?, ?, 'draft', ?, ?, ?)`,
      [
        invoiceNo,
        Number(cusomer_id),
        invoice_date,
        due_date,
        subtotal,
        taxAmount,
        total
      ]
    );

    const invoiceId = result.insertId;

    for (const item of cleanItems) {
      await connection.execute(
        `INSERT INTO invoice_line_items
        (description, quantity, unit_price, tax_rate,
         line_total, invoice_id)
        VALUES (?, ?, ?, ?, ?, ?)`,
        [
          item.description,
          item.quantity,
          item.unitPrice,
          item.taxRate,
          item.lineTotal,
          invoiceId
        ]
      );
    }

    await connection.commit();

    res.status(201).json({
      message: 'Draft invoice created successfully',
      invoice_id: invoiceId,
      invoice_no: invoiceNo,
      status: 'draft',
      subtotal,
      tax_amount: taxAmount,
      total
    });
  } catch (error) {
    await connection.rollback();
    console.error(error);

    res.status(500).json({
      message: 'Failed to create invoice'
    });
  } finally {
    connection.release();
  }
});


// API 2: List Invoices
// GET /api/invoices?status=issued&customer_id=1
router.get('/', async (req, res) => {
  try {
    const { status, customer_id } = req.query;

    const allowedStatuses = ['draft', 'issued', 'partial', 'paid'];

    if (status && !allowedStatuses.includes(status)) {
      return res.status(400).json({
        message: 'Invalid status filter'
      });
    }

    if (
      customer_id &&
      (!/^\d+$/.test(customer_id) || Number(customer_id) <= 0)
    ) {
      return res.status(400).json({
        message: 'Invalid customer_id'
      });
    }

    let sql = `
      SELECT
        i.id,
        i.unique_invoice_no,
        i.cusomer_id AS customer_id,
        c.name AS customer_name,
        i.invoice_date,
        i.due_date,
        CASE
          WHEN i.status = 'issued' AND COALESCE(p.paid_amount, 0) > 0
               AND COALESCE(p.paid_amount, 0) >= i.total THEN 'paid'
          WHEN i.status = 'issued' AND COALESCE(p.paid_amount, 0) > 0 THEN 'partial'
          ELSE i.status
        END AS status,
        i.subtotal,
        i.tax_amount,
        i.total,
        COALESCE(p.paid_amount, 0) AS paid_amount,
        GREATEST(
          i.total - COALESCE(p.paid_amount, 0), 0
        ) AS balance_due
      FROM invoice i
      JOIN customer c ON c.id = i.cusomer_id
      LEFT JOIN (
        SELECT invoice_id, SUM(amount) AS paid_amount
        FROM payments
        GROUP BY invoice_id
      ) p ON p.invoice_id = i.id
      WHERE 1=1
    `;

    const params = [];

    if (status) {
      if (status === 'partial') {
        sql += ` AND (
          i.status = 'partial' OR (
            i.status = 'issued' AND COALESCE(p.paid_amount, 0) > 0
            AND COALESCE(p.paid_amount, 0) < i.total
          )
        )`;
      } else if (status === 'paid') {
        sql += ` AND (
          i.status = 'paid' OR (
            i.status = 'issued' AND COALESCE(p.paid_amount, 0) > 0
            AND COALESCE(p.paid_amount, 0) >= i.total
          )
        )`;
      } else if (status === 'issued') {
        sql += ` AND i.status = 'issued' AND COALESCE(p.paid_amount, 0) = 0`;
      } else {
        sql += ' AND i.status = ?';
        params.push(status);
      }
    }

    if (customer_id) {
      sql += ' AND i.cusomer_id = ?';
      params.push(Number(customer_id));
    }

    sql += ' ORDER BY i.id DESC';

    const [rows] = await db.execute(sql, params);

    res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({
      message: 'Failed to list invoices'
    });
  }
});


// API 3: Show One Invoice + Items + Payments
// GET /api/invoices/:id
router.get('/:id', async (req, res) => {
  try {
    const id = req.params.id;

    if (!/^\d+$/.test(id) || Number(id) <= 0) {
      return res.status(400).json({
        message: 'Invalid invoice ID'
      });
    }

    const [invoices] = await db.execute(
      `SELECT
         i.*,
         c.name AS customer_name,
         c.email AS customer_email,
         c.phn AS customer_phone,
         COALESCE(p.paid_amount, 0) AS paid_amount,
         CASE
           WHEN i.status = 'issued' AND COALESCE(p.paid_amount, 0) > 0
                AND COALESCE(p.paid_amount, 0) >= i.total THEN 'paid'
           WHEN i.status = 'issued' AND COALESCE(p.paid_amount, 0) > 0 THEN 'partial'
           ELSE i.status
         END AS effective_status,
         GREATEST(
           i.total - COALESCE(p.paid_amount, 0), 0
         ) AS balance_due
       FROM invoice i
       JOIN customer c ON c.id = i.cusomer_id
       LEFT JOIN (
         SELECT invoice_id, SUM(amount) AS paid_amount
         FROM payments
         GROUP BY invoice_id
       ) p ON p.invoice_id = i.id
       WHERE i.id = ?`,
      [Number(id)]
    );

    if (invoices.length === 0) {
      return res.status(404).json({
        message: 'Invoice not found'
      });
    }

    const [items] = await db.execute(
      `SELECT id, description, quantity, unit_price,
              tax_rate, line_total
       FROM invoice_line_items
       WHERE invoice_id = ?
       ORDER BY id`,
      [Number(id)]
    );

    const [payments] = await db.execute(
      `SELECT id, date, amount,
              payment_method, reference_no
       FROM payments
       WHERE invoice_id = ?
       ORDER BY date DESC, id DESC`,
      [Number(id)]
    );

    const { effective_status, ...invoice } = invoices[0];
    res.json({
      ...invoice,
      status: effective_status,
      items,
      payments
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      message: 'Failed to fetch invoice'
    });
  }
});

// API 3: Update a Draft Invoice
// PUT /api/invoices/:id
router.put('/:id', async (req, res) => {
  let connection;
  try {
    const id = req.params.id;
    const { cusomer_id, invoice_date, due_date, items } = req.body;

    if (!/^\d+$/.test(id) || Number(id) <= 0) {
      return res.status(400).json({ message: 'Invalid invoice ID' });
    }
    if (!Number.isInteger(Number(cusomer_id)) || Number(cusomer_id) <= 0) {
      return res.status(400).json({ message: 'A valid customer is required' });
    }
    const dateError = validInvoiceDates(invoice_date, due_date);
    if (dateError) return res.status(400).json({ message: dateError });
    const calculated = calculateInvoiceItems(items);
    if (calculated.error) return res.status(400).json({ message: calculated.error });

    connection = await db.getConnection();
    await connection.beginTransaction();
    const [invoices] = await connection.execute(
      'SELECT id, status FROM invoice WHERE id = ? FOR UPDATE',
      [Number(id)]
    );
    if (!invoices.length) {
      await connection.rollback();
      return res.status(404).json({ message: 'Invoice not found' });
    }
    if (invoices[0].status !== 'draft') {
      await connection.rollback();
      return res.status(400).json({ message: 'Only draft invoices can be edited' });
    }

    const [customers] = await connection.execute(
      'SELECT id FROM customer WHERE id = ?',
      [Number(cusomer_id)]
    );
    if (!customers.length) {
      await connection.rollback();
      return res.status(404).json({ message: 'Customer not found' });
    }

    const { cleanItems, subtotal, taxAmount, total } = calculated;
    await connection.execute(
      `UPDATE invoice
       SET cusomer_id = ?, invoice_date = ?, due_date = ?,
           subtotal = ?, tax_amount = ?, total = ?
       WHERE id = ? AND status = 'draft'`,
      [Number(cusomer_id), invoice_date, due_date, subtotal, taxAmount, total, Number(id)]
    );
    await connection.execute('DELETE FROM invoice_line_items WHERE invoice_id = ?', [Number(id)]);
    for (const item of cleanItems) {
      await connection.execute(
        `INSERT INTO invoice_line_items
         (description, quantity, unit_price, tax_rate, line_total, invoice_id)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [item.description, item.quantity, item.unitPrice, item.taxRate, item.lineTotal, Number(id)]
      );
    }

    await connection.commit();
    res.json({
      message: 'Draft invoice updated successfully',
      invoice_id: Number(id),
      status: 'draft',
      subtotal,
      tax_amount: taxAmount,
      total
    });
  } catch (error) {
    if (connection) await connection.rollback();
    console.error(error);
    res.status(500).json({ message: 'Failed to update invoice' });
  } finally {
    if (connection) connection.release();
  }
});

// API 4: Delete a Draft Invoice
// DELETE /api/invoices/:id
router.delete('/:id', async (req, res) => {
  let connection;
  try {
    const id = req.params.id;
    if (!/^\d+$/.test(id) || Number(id) <= 0) {
      return res.status(400).json({ message: 'Invalid invoice ID' });
    }

    connection = await db.getConnection();
    await connection.beginTransaction();
    const [invoices] = await connection.execute(
      'SELECT id, status FROM invoice WHERE id = ? FOR UPDATE',
      [Number(id)]
    );
    if (!invoices.length) {
      await connection.rollback();
      return res.status(404).json({ message: 'Invoice not found' });
    }
    if (invoices[0].status !== 'draft') {
      await connection.rollback();
      return res.status(400).json({ message: 'Only draft invoices can be deleted' });
    }

    await connection.execute('DELETE FROM invoice_line_items WHERE invoice_id = ?', [Number(id)]);
    await connection.execute('DELETE FROM invoice WHERE id = ? AND status = \'draft\'', [Number(id)]);
    await connection.commit();
    res.json({ message: 'Draft invoice deleted successfully', invoice_id: Number(id) });
  } catch (error) {
    if (connection) await connection.rollback();
    console.error(error);
    res.status(500).json({ message: 'Failed to delete invoice' });
  } finally {
    if (connection) connection.release();
  }
});


// API 5: Issue a Draft Invoice
// PATCH /api/invoices/:id/issue
router.patch('/:id/issue', async (req, res) => {
  let connection;

  try {
    const id = req.params.id;

    if (!/^\d+$/.test(id) || Number(id) <= 0) {
      return res.status(400).json({
        message: 'Invalid invoice ID'
      });
    }

    connection = await db.getConnection();
    await connection.beginTransaction();

    // Lock invoice while checking status
    const [invoices] = await connection.execute(
      `SELECT id, status
       FROM invoice
       WHERE id = ?
       FOR UPDATE`,
      [Number(id)]
    );

    if (invoices.length === 0) {
      await connection.rollback();
      return res.status(404).json({
        message: 'Invoice not found'
      });
    }

    if (invoices[0].status !== 'draft') {
      await connection.rollback();
      return res.status(400).json({
        message: 'Only draft invoices can be issued'
      });
    }

    const [items] = await connection.execute(
      `SELECT id FROM invoice_line_items
       WHERE invoice_id = ? LIMIT 1`,
      [Number(id)]
    );

    if (items.length === 0) {
      await connection.rollback();
      return res.status(400).json({
        message: 'Cannot issue invoice without line items'
      });
    }

    const [invoiceTotals] = await connection.execute(
      'SELECT unique_invoice_no, invoice_date, subtotal, tax_amount, total FROM invoice WHERE id = ?',
      [Number(id)]
    );
    const totals = invoiceTotals[0];
    if (Number(totals.total) <= 0) {
      await connection.rollback();
      return res.status(400).json({
        message: 'Cannot issue an invoice with a zero total'
      });
    }

    const journalLines = [
      {
        accountCode: '1100',
        description: `Accounts receivable for ${totals.unique_invoice_no}`,
        debit: totals.total,
        credit: 0
      },
      {
        accountCode: '4000',
        description: `Sales revenue for ${totals.unique_invoice_no}`,
        debit: 0,
        credit: totals.subtotal
      }
    ];
    if (Number(totals.tax_amount) > 0) {
      journalLines.push({
        accountCode: '2100',
        description: `Tax payable for ${totals.unique_invoice_no}`,
        debit: 0,
        credit: totals.tax_amount
      });
    }
    await createPostedJournal(connection, {
      entryDate: totals.invoice_date,
      referenceType: 'invoice',
      referenceId: Number(id),
      description: `Invoice issued: ${totals.unique_invoice_no}`,
      lines: journalLines
    });

    await connection.execute(
      `UPDATE invoice
       SET status = 'issued'
       WHERE id = ? AND status = 'draft'`,
      [Number(id)]
    );

    await connection.commit();

    res.json({
      message: 'Invoice issued successfully',
      invoice_id: Number(id),
      status: 'issued'
    });
  } catch (error) {
    if (connection) await connection.rollback();
    console.error(error);

    res.status(500).json({
      message: 'Failed to issue invoice'
    });
  } finally {
    if (connection) connection.release();
  }
});

module.exports = router;
