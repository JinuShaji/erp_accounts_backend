const express = require('express');
const db = require('../config/db');
const router = express.Router();

// API 1: Customer Creation
// POST /api/customers
router.post('/', async (req, res) => {
  try {
    const { name, email, phn, gst_no } = req.body;

    if (!name || !email || !phn || !gst_no) {
      return res.status(400).json({
        message: 'All fields are required'
      });
    }

    const sql = `
      INSERT INTO customer (name, email, phn, gst_no)
      VALUES (?, ?, ?, ?)
    `;

    const [result] = await db.execute(sql, [
      name.trim(),
      email.trim(),
      phn.trim(),
      String(gst_no).trim()
    ]);

    res.status(201).json({
      message: 'Customer created successfully',
      id: result.insertId
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      message: 'Failed to create customer'
    });
  }
});

// API 2: Customer Listing
// GET /api/customers
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.execute(`
      SELECT id, name, email, phn, gst_no
      FROM customer
      ORDER BY id DESC
    `);

    res.status(200).json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({
      message: 'Failed to fetch customers'
    });
  }
});

module.exports = router;
