const express = require('express');
const db = require('../config/db');
const { createPostedJournal } = require('../utils/journals');

const router = express.Router();

// POST /api/payments
// Record payment against an invoice
router.post('/', async (req, res) => {
  const {
    cusomer_id,
    invoice_id,
    date,
    amount,
    payment_method,
    reference_no
  } = req.body;

  if (
    !Number.isInteger(Number(cusomer_id)) ||
    Number(cusomer_id) <= 0 ||
    !Number.isInteger(Number(invoice_id)) ||
    Number(invoice_id) <= 0 ||
    typeof date !== 'string' ||
    !/^\d{4}-\d{2}-\d{2}$/.test(date) ||
    Number.isNaN(Date.parse(date)) ||
    new Date(date).toISOString().slice(0, 10) !== date ||
    amount === undefined ||
    amount === null ||
    !Number.isFinite(Number(amount)) ||
    Number(amount) <= 0 ||
    typeof payment_method !== 'string' ||
    !payment_method.trim() ||
    payment_method.trim().length > 30 ||
    (reference_no !== undefined && reference_no !== null &&
      (typeof reference_no !== 'string' || reference_no.trim().length > 100))
  ) {
    return res.status(400).json({
      message: 'All required fields must be valid'
    });
  }

  const paymentAmount = Number(Number(amount).toFixed(2));
  if (paymentAmount <= 0 || paymentAmount !== Number(amount)) {
    return res.status(400).json({
      message: 'Payment amount must be at least ₹0.01 and have no more than two decimal places'
    });
  }

  let connection;

  try {
    connection = await db.getConnection();
    await connection.beginTransaction();

    // Lock invoice during payment processing
    const [invoices] = await connection.execute(
      `SELECT id, cusomer_id, total, status
       FROM invoice
       WHERE id = ? AND cusomer_id = ?
       FOR UPDATE`,
      [Number(invoice_id), Number(cusomer_id)]
    );

    if (!invoices.length) {
      await connection.rollback();
      return res.status(404).json({
        message: 'Invoice not found'
      });
    }

    const invoice = invoices[0];

    if (invoice.status !== 'issued' && invoice.status !== 'partial') {
      await connection.rollback();
      return res.status(400).json({
        message: 'Payment can only be recorded for issued or partially paid invoices'
      });
    }

    // Calculate existing payments
    const [paymentRows] = await connection.execute(
      `SELECT COALESCE(SUM(amount), 0) AS paid
       FROM payments
       WHERE invoice_id = ?`,
      [Number(invoice_id)]
    );

    const total = Number(invoice.total);
    const paid = Number(paymentRows[0].paid);
    const balance = Number((total - paid).toFixed(2));

    if (paymentAmount > balance) {
      await connection.rollback();
      const formatMoney = (value) => new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        maximumFractionDigits: 2
      }).format(value);
      return res.status(400).json({
        message: `Payment amount ${formatMoney(paymentAmount)} exceeds the remaining balance of ${formatMoney(Math.max(0, balance))}`,
        balance_due: Math.max(0, balance)
      });
    }

    // Insert payment
    const [result] = await connection.execute(
      `INSERT INTO payments
       (cusomer_id, \`date\`, amount, payment_method,
        reference_no, invoice_id)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [
        Number(cusomer_id),
        date,
        paymentAmount,
        payment_method.trim(),
        typeof reference_no === 'string' && reference_no.trim() ? reference_no.trim() : null,
        Number(invoice_id)
      ]
    );

    const newPaid = Number((paid + paymentAmount).toFixed(2));
    const newBalance = Number((total - newPaid).toFixed(2));

    const cashAccount = payment_method.trim().toLowerCase() === 'cash' ? '1000' : '1010';
    await createPostedJournal(connection, {
      entryDate: date,
      referenceType: 'payment',
      referenceId: result.insertId,
      description: `Payment received for invoice ${invoice_id}`,
      lines: [
        {
          accountCode: cashAccount,
          description: `Funds received by ${payment_method.trim()}`,
          debit: paymentAmount,
          credit: 0
        },
        {
          accountCode: '1100',
          description: `Accounts receivable settled for invoice ${invoice_id}`,
          debit: 0,
          credit: paymentAmount
        }
      ]
    });

    const newStatus = newBalance <= 0.001 ? 'paid' : 'partial';
    await connection.execute(
      'UPDATE invoice SET status = ? WHERE id = ?',
      [newStatus, Number(invoice_id)]
    );

    await connection.commit();

    res.status(201).json({
      message: 'Payment recorded successfully',
      payment_id: result.insertId,
      invoice_id: Number(invoice_id),
      amount_paid: paymentAmount,
      total_paid: newPaid,
      balance_due: Math.max(0, newBalance),
      status: newStatus
    });

  } catch (error) {
    if (connection) {
      await connection.rollback();
    }

    console.error(error);
    res.status(500).json({
      message: 'Failed to record payment'
    });
  } finally {
    if (connection) connection.release();
  }
});

// GET /api/payments/customer-outstanding
router.get('/customer-outstanding', async (req, res) => {
  try {
    const [rows] = await db.execute(`
      SELECT
        c.id AS customer_id,
        c.name AS customer_name,
        SUM(i.total) AS total_invoiced,
        SUM(COALESCE(p.paid, 0)) AS total_paid,
        SUM(i.total - COALESCE(p.paid, 0)) AS amount_owed
      FROM customer c
      JOIN invoice i
        ON i.cusomer_id = c.id
      LEFT JOIN (
        SELECT
          invoice_id,
          SUM(amount) AS paid
        FROM payments
        GROUP BY invoice_id
      ) p ON p.invoice_id = i.id
      WHERE i.status IN ('issued', 'partial')
      GROUP BY c.id, c.name
      HAVING amount_owed > 0.001
      ORDER BY amount_owed DESC
    `);

    res.json({
      count: rows.length,
      customers: rows
    });

  } catch (error) {
    console.error(error);
    res.status(500).json({
      message: 'Failed to fetch customer outstanding amounts'
    });
  }
});
module.exports = router;