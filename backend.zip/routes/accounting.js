const express = require('express');
const db = require('../config/db');
const { createPostedJournal } = require('../utils/journals');

const router = express.Router();
const debitNormalTypes = ['asset', 'expense'];

router.get('/accounts', async (req, res) => {
  try {
    const [accounts] = await db.execute(`
      SELECT
        a.id,
        a.account_code,
        a.name,
        a.type,
        COALESCE(SUM(CASE WHEN j.status = 'posted' THEN l.debit ELSE 0 END), 0) AS total_debit,
        COALESCE(SUM(CASE WHEN j.status = 'posted' THEN l.credit ELSE 0 END), 0) AS total_credit
      FROM accounts a
      LEFT JOIN journal_entry_lines l ON l.account_id = a.id
      LEFT JOIN journal_entries j
        ON j.id = l.journal_entry_id AND j.status = 'posted'
      GROUP BY a.id, a.account_code, a.name, a.type
      ORDER BY a.account_code
    `);

    res.json(accounts.map((account) => {
      const netDebit = Number(account.total_debit) - Number(account.total_credit);
      const debitNormal = debitNormalTypes.includes(account.type);
      const balance = debitNormal ? netDebit : -netDebit;
      return {
        ...account,
        current_balance: Math.abs(balance),
        balance_side: balance === 0
          ? '—'
          : balance > 0
            ? (debitNormal ? 'debit' : 'credit')
            : (debitNormal ? 'credit' : 'debit')
      };
    }));
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Failed to fetch chart of accounts' });
  }
});

router.get('/journal_entries', async (req, res) => {
  try {
    const [entries] = await db.execute(`
      SELECT id, entry_date, reference_type, reference_id,
             description, status, created_at
      FROM journal_entries
      WHERE status = 'posted'
      ORDER BY entry_date DESC, id DESC
    `);

    if (!entries.length) return res.json([]);
    const ids = entries.map((entry) => entry.id);
    const placeholders = ids.map(() => '?').join(', ');
    const [lines] = await db.execute(
      `SELECT l.id, l.journal_entry_id, l.description,
              l.debit, l.credit, a.id AS account_id,
              a.account_code, a.name AS account_name, a.type AS account_type
       FROM journal_entry_lines l
       JOIN accounts a ON a.id = l.account_id
       WHERE l.journal_entry_id IN (${placeholders})
       ORDER BY l.journal_entry_id, l.id`,
      ids
    );

    const linesByEntry = new Map();
    for (const line of lines) {
      const current = linesByEntry.get(line.journal_entry_id) || [];
      current.push(line);
      linesByEntry.set(line.journal_entry_id, current);
    }

    res.json(entries.map((entry) => ({
      ...entry,
      lines: linesByEntry.get(entry.id) || []
    })));
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Failed to fetch journal entries' });
  }
});

router.get('/report/trial-balance', async (req, res) => {
  try {
    const [accounts] = await db.execute(`
      SELECT
        a.id,
        a.account_code,
        a.name,
        a.type,
        COALESCE(SUM(CASE WHEN j.status = 'posted' THEN l.debit ELSE 0 END), 0) AS total_debit,
        COALESCE(SUM(CASE WHEN j.status = 'posted' THEN l.credit ELSE 0 END), 0) AS total_credit
      FROM accounts a
      LEFT JOIN journal_entry_lines l ON l.account_id = a.id
      LEFT JOIN journal_entries j
        ON j.id = l.journal_entry_id AND j.status = 'posted'
      GROUP BY a.id, a.account_code, a.name, a.type
      ORDER BY a.account_code
    `);

    const rows = accounts.map((account) => {
      const totalDebit = Number(account.total_debit);
      const totalCredit = Number(account.total_credit);
      const netDebit = Number((totalDebit - totalCredit).toFixed(2));
      return {
        ...account,
        total_debit: totalDebit,
        total_credit: totalCredit,
        debit_balance: netDebit > 0 ? netDebit : 0,
        credit_balance: netDebit < 0 ? -netDebit : 0
      };
    });

    const totals = rows.reduce((result, account) => ({
      total_debit: Number((result.total_debit + account.total_debit).toFixed(2)),
      total_credit: Number((result.total_credit + account.total_credit).toFixed(2)),
      debit_balance: Number((result.debit_balance + account.debit_balance).toFixed(2)),
      credit_balance: Number((result.credit_balance + account.credit_balance).toFixed(2))
    }), { total_debit: 0, total_credit: 0, debit_balance: 0, credit_balance: 0 });

    res.json({
      accounts: rows,
      totals,
      balanced: Math.abs(totals.debit_balance - totals.credit_balance) < 0.01 &&
        Math.abs(totals.total_debit - totals.total_credit) < 0.01
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Failed to fetch trial balance' });
  }
});

router.post('/journal_entries', async (req, res) => {
  const { entry_date, description, lines } = req.body;
  if (
    typeof entry_date !== 'string' ||
    !/^\d{4}-\d{2}-\d{2}$/.test(entry_date) ||
    Number.isNaN(Date.parse(entry_date)) ||
    new Date(entry_date).toISOString().slice(0, 10) !== entry_date ||
    typeof description !== 'string' ||
    !description.trim() ||
    !Array.isArray(lines) ||
    lines.length < 2
  ) {
    return res.status(400).json({
      message: 'A valid date, description, and at least two journal lines are required'
    });
  }

  let connection;
  try {
    connection = await db.getConnection();
    await connection.beginTransaction();
    const accountIds = [...new Set(lines.map((line) => Number(line.account_id)))];
    if (accountIds.some((id) => !Number.isInteger(id) || id <= 0)) {
      await connection.rollback();
      return res.status(400).json({ message: 'Every journal line must have a valid account' });
    }
    const placeholders = accountIds.map(() => '?').join(', ');
    const [accounts] = await connection.execute(
      `SELECT id, account_code FROM accounts WHERE id IN (${placeholders})`,
      accountIds
    );
    const accountCodeById = new Map(accounts.map((account) => [Number(account.id), account.account_code]));
    const normalizedLines = lines.map((line) => ({
      ...line,
      accountCode: accountCodeById.get(Number(line.account_id))
    }));
    if (normalizedLines.some((line) => !line.accountCode)) {
      await connection.rollback();
      return res.status(400).json({ message: 'A journal line references an unknown account' });
    }

    const entry = await createPostedJournal(connection, {
      entryDate: entry_date,
      referenceType: 'manual',
      description: description.trim(),
      lines: normalizedLines
    });
    await connection.commit();
    res.status(201).json({
      message: 'Journal entry posted successfully',
      journal_entry_id: entry.id,
      total_debit: entry.debitTotal,
      total_credit: entry.creditTotal
    });
  } catch (error) {
    if (connection) await connection.rollback();
    if (error.message.startsWith('Journal entry is unbalanced') ||
        error.message.startsWith('Each journal line') ||
        error.message.startsWith('A journal entry')) {
      return res.status(400).json({ message: error.message });
    }
    console.error(error);
    res.status(500).json({ message: 'Failed to post journal entry' });
  } finally {
    if (connection) connection.release();
  }
});

module.exports = router;
