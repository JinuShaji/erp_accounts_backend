function roundMoney(value) {
  return Number(Number(value).toFixed(2));
}

async function createPostedJournal(connection, {
  entryDate,
  referenceType,
  referenceId = null,
  description,
  lines
}) {
  if (!Array.isArray(lines) || lines.length < 2) {
    throw new Error('A journal entry must contain at least two lines');
  }

  const cleanLines = lines.map((line) => ({
    accountCode: String(line.accountCode),
    description: line.description || null,
    debit: roundMoney(line.debit || 0),
    credit: roundMoney(line.credit || 0)
  }));
  const debitTotal = roundMoney(cleanLines.reduce((sum, line) => sum + line.debit, 0));
  const creditTotal = roundMoney(cleanLines.reduce((sum, line) => sum + line.credit, 0));

  if (cleanLines.some((line) =>
    !Number.isFinite(line.debit) ||
    !Number.isFinite(line.credit) ||
    line.debit < 0 ||
    line.credit < 0 ||
    (line.debit === 0 && line.credit === 0) ||
    (line.debit > 0 && line.credit > 0)
  )) {
    throw new Error('Each journal line must have either a positive debit or a positive credit');
  }
  if (debitTotal <= 0 || debitTotal !== creditTotal) {
    throw new Error(`Journal entry is unbalanced: debits ${debitTotal.toFixed(2)}, credits ${creditTotal.toFixed(2)}`);
  }

  const codes = [...new Set(cleanLines.map((line) => line.accountCode))];
  const placeholders = codes.map(() => '?').join(', ');
  const [accounts] = await connection.execute(
    `SELECT id, account_code FROM accounts WHERE account_code IN (${placeholders})`,
    codes
  );
  const accountIds = new Map(accounts.map((account) => [account.account_code, account.id]));
  const missingCode = codes.find((code) => !accountIds.has(code));
  if (missingCode) throw new Error(`Journal account ${missingCode} does not exist`);

  const [entryResult] = await connection.execute(
    `INSERT INTO journal_entries
     (entry_date, reference_type, reference_id, description, status)
     VALUES (?, ?, ?, ?, 'posted')`,
    [entryDate, referenceType, referenceId, description]
  );

  for (const line of cleanLines) {
    await connection.execute(
      `INSERT INTO journal_entry_lines
       (journal_entry_id, account_id, description, debit, credit)
       VALUES (?, ?, ?, ?, ?)`,
      [entryResult.insertId, accountIds.get(line.accountCode), line.description, line.debit, line.credit]
    );
  }

  return { id: entryResult.insertId, debitTotal, creditTotal };
}

module.exports = { createPostedJournal, roundMoney };
